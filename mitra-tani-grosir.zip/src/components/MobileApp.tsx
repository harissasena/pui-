/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  Search, 
  MapPin, 
  Bell, 
  Home, 
  Grid, 
  ShoppingCart, 
  User, 
  Filter,
  ChevronRight,
  Star,
  Info,
  Clock,
  LogOut
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { PRODUCTS } from '../constants';

export default function MobileApp() {
  const [activeTab, setActiveTab] = useState('home');
  const [selectedCategory, setSelectedCategory] = useState('Semua');

  const categories = ['Semua', 'Sembako', 'Jajanan', 'Minuman', 'Kebutuhan Rumah'];
  const filteredProducts = selectedCategory === 'Semua' 
    ? PRODUCTS 
    : PRODUCTS.filter(p => p.category === selectedCategory);

  return (
    <div className="max-w-[420px] mx-auto h-[840px] bg-white shadow-2xl rounded-[3rem] border-[8px] border-gray-800 overflow-hidden relative flex flex-col font-sans">
      {/* Notch / Status Bar Area */}
      <div className="h-6 bg-white w-full flex justify-center items-center">
        <div className="w-20 h-6 bg-gray-800 rounded-b-xl"></div>
      </div>

      {/* App Content */}
      <div className="flex-1 overflow-y-auto pb-24 scrollbar-hide">
        {/* Header */}
        <header className="px-6 pt-4 pb-2 sticky top-0 bg-white z-20">
          <div className="flex items-center justify-between mb-4">
            <div className="flex flex-col">
              <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Lokasi Toko</span>
              <div className="flex items-center gap-1 text-emerald-600 font-bold">
                <MapPin size={14} />
                <span className="text-[10px] sm:text-xs">Dwipa Karya, Bangga, Sulteng</span>
              </div>
            </div>
            <button className="w-10 h-10 bg-gray-50 rounded-full flex items-center justify-center relative">
              <Bell size={20} className="text-gray-600" />
              <span className="absolute top-2 right-2 w-2 h-2 bg-emerald-500 rounded-full border-2 border-white"></span>
            </button>
          </div>

          <div className="relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
            <input 
              type="text" 
              placeholder="Cari Beras Pandan Wangi..." 
              className="w-full bg-gray-100 border-none rounded-2xl py-3 pl-12 pr-4 text-sm focus:ring-2 focus:ring-emerald-500 outline-none transition-all"
            />
          </div>
        </header>

        {activeTab === 'home' && (
          <motion.div 
            initial={{ opacity: 0 }} 
            animate={{ opacity: 1 }}
            className="px-6 space-y-6 pt-4"
          >
            {/* Hero Banner */}
            <div className="relative h-44 rounded-3xl overflow-hidden shadow-lg shadow-emerald-100">
              <img 
                src="https://images.unsplash.com/photo-1542838132-92c53300491e?auto=format&fit=crop&q=80&w=800" 
                className="w-full h-full object-cover" 
                alt="Stock Banner" 
              />
              <div className="absolute inset-0 bg-gradient-to-r from-black/60 to-transparent flex flex-col justify-center px-6">
                <h2 className="text-white font-bold text-xl leading-tight mb-2">Stok Baru<br/>Tiba Hari Ini</h2>
                <p className="text-emerald-300 text-[10px] font-bold uppercase tracking-wider">Harga Turun 5% Untuk Sembako</p>
                <button className="mt-4 bg-emerald-500 text-white text-[10px] font-bold px-4 py-2 rounded-lg w-fit">BELI SEKARANG</button>
              </div>
            </div>

            {/* Categories */}
            <div className="flex gap-3 overflow-x-auto scrollbar-hide py-2 -mx-2 px-2">
              {categories.map(cat => (
                <button
                  key={cat}
                  onClick={() => setSelectedCategory(cat)}
                  className={`px-6 py-2.5 rounded-2xl text-xs font-bold whitespace-nowrap transition-all border ${
                    selectedCategory === cat 
                    ? 'bg-emerald-600 text-white border-emerald-600 shadow-md shadow-emerald-100' 
                    : 'bg-white text-gray-500 border-gray-100'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>

            {/* Product Grid */}
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="font-bold text-lg">Produk Terlaris</h3>
                <Filter size={18} className="text-gray-400" />
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                {filteredProducts.map((product, idx) => (
                  <motion.div 
                    key={product.id}
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ delay: idx * 0.05 }}
                    className="bg-white rounded-3xl border border-gray-100 p-3 shadow-sm hover:shadow-md transition-shadow"
                  >
                    <div className="relative rounded-2xl overflow-hidden aspect-square mb-3">
                      <img src={product.image} className="w-full h-full object-cover" alt="" />
                      <div className="absolute top-2 right-2 bg-white/90 backdrop-blur-sm p-1 rounded-lg">
                        <Star className="text-orange-400 fill-orange-400" size={10} />
                      </div>
                      <div className="absolute bottom-2 left-2 bg-emerald-600 text-white text-[8px] font-bold px-2 py-0.5 rounded-full uppercase">
                        Min. {product.minOrder} {product.unit}
                      </div>
                    </div>
                    <div className="space-y-1">
                      <p className="text-[10px] font-bold text-emerald-600 uppercase tracking-wider">{product.category}</p>
                      <h4 className="text-xs font-bold line-clamp-1">{product.name}</h4>
                      <div className="flex items-baseline gap-1">
                        <span className="text-xs font-bold">Rp{product.price.toLocaleString('id-ID')}</span>
                        <span className="text-[9px] text-gray-400">/{product.unit}</span>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>
          </motion.div>
        )}

        {activeTab === 'catalog' && (
          <div className="p-6">
            <h2 className="font-bold text-2xl mb-4">Katalog Grosir</h2>
            <div className="grid grid-cols-1 gap-4">
              {categories.slice(1).map(cat => (
                <div key={cat} className="bg-gray-50 p-4 rounded-2xl flex items-center justify-between border border-gray-100 cursor-pointer hover:bg-emerald-50 transition-all">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 bg-white rounded-xl flex items-center justify-center shadow-sm">
                      <Grid className="text-emerald-600" size={24} />
                    </div>
                    <div>
                      <p className="font-bold text-sm">{cat}</p>
                      <p className="text-[10px] text-gray-500">Lihat semua produk {cat}</p>
                    </div>
                  </div>
                  <ChevronRight size={18} className="text-gray-300" />
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === 'orders' && (
          <div className="p-6 space-y-6">
            <h2 className="font-bold text-2xl">Pesanan Saya</h2>
            <div className="space-y-4">
              {[1, 2].map(i => (
                <div key={i} className="bg-white border border-gray-100 rounded-3xl p-4 shadow-sm">
                  <div className="flex justify-between items-center mb-3">
                    <span className="text-[10px] font-bold text-emerald-600 px-2 py-1 bg-emerald-50 rounded-lg">#TRX-9821{i}</span>
                    <span className="text-[10px] font-bold text-orange-500">DIKIRIM</span>
                  </div>
                  <div className="flex items-center gap-4 mb-4">
                    <div className="w-16 h-16 bg-gray-100 rounded-2xl overflow-hidden">
                      <img src={PRODUCTS[i].image} className="w-full h-full object-cover" alt="" />
                    </div>
                    <div>
                      <p className="font-bold text-sm">{PRODUCTS[i].name}</p>
                      <p className="text-[10px] text-gray-500">{PRODUCTS[i].minOrder} x Rp {PRODUCTS[i].price.toLocaleString('id-ID')}</p>
                    </div>
                  </div>
                  <div className="flex justify-between items-center pt-3 border-t border-gray-50">
                    <p className="text-xs text-gray-500">Total Belanja</p>
                    <p className="font-bold text-sm text-emerald-600">Rp {(PRODUCTS[i].price * PRODUCTS[i].minOrder).toLocaleString('id-ID')}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === 'cart' && (
          <div className="p-6 space-y-6">
            <h2 className="font-bold text-2xl">Keranjang Belanja</h2>
            <div className="space-y-4">
              {[0, 1, 3].map(i => (
                <div key={i} className="flex items-center gap-4 bg-gray-50 p-3 rounded-2xl border border-gray-100">
                  <img src={PRODUCTS[i].image} className="w-16 h-16 rounded-xl object-cover" alt="" />
                  <div className="flex-1">
                    <p className="font-bold text-sm tracking-tight">{PRODUCTS[i].name}</p>
                    <p className="text-[10px] text-gray-500">Min. {PRODUCTS[i].minOrder} {PRODUCTS[i].unit}</p>
                    <p className="text-sm font-bold text-emerald-600 mt-1">Rp {PRODUCTS[i].price.toLocaleString('id-ID')}</p>
                  </div>
                  <div className="flex flex-col items-center gap-2">
                    <div className="flex items-center gap-2 bg-white px-2 py-1 rounded-lg border border-gray-100">
                      <button className="text-emerald-600 font-bold">-</button>
                      <span className="text-xs font-bold w-4 text-center">{PRODUCTS[i].minOrder}</span>
                      <button className="text-emerald-600 font-bold">+</button>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className="fixed bottom-28 left-6 right-6 bg-white p-4 rounded-3xl border border-gray-100 shadow-xl space-y-4">
              <div className="space-y-2">
                <div className="flex justify-between text-xs text-gray-400">
                  <span>Subtotal (3 Barang)</span>
                  <span>Rp 4.250.000</span>
                </div>
                <div className="flex justify-between text-xs text-gray-400">
                  <span>Biaya Pengiriman</span>
                  <span className="text-emerald-600 font-bold">GRATIS</span>
                </div>
                <div className="h-px bg-gray-50 my-2"></div>
                <div className="flex justify-between font-bold text-lg">
                  <span>Total Bayar</span>
                  <span className="text-emerald-600">Rp 4.250.000</span>
                </div>
              </div>
              <button 
                onClick={() => setActiveTab('orders')}
                className="w-full bg-emerald-600 text-white font-bold py-4 rounded-2xl shadow-lg shadow-emerald-100 active:scale-95 transition-all"
              >
                Pesan Sekarang
              </button>
            </div>
          </div>
        )}

        {activeTab === 'profile' && (
          <div className="p-6 space-y-8">
            <div className="flex flex-col items-center gap-4 mt-8">
              <div className="w-24 h-24 rounded-full border-4 border-emerald-100 p-1 relative">
                <img 
                  src="https://images.unsplash.com/photo-1522529599102-193c0d76b5b6?auto=format&fit=crop&q=80&w=200" 
                  className="w-full h-full rounded-full object-cover" 
                  alt="Profile" 
                />
                <div className="absolute bottom-1 right-1 bg-emerald-500 w-6 h-6 rounded-full border-4 border-white"></div>
              </div>
              <div className="text-center">
                <h3 className="font-bold text-xl">Andi Setiawan</h3>
                <p className="text-gray-400 text-xs">Pemilik Toko Andi - Dwipa Karya</p>
              </div>
            </div>

            <div className="space-y-3">
              <ProfileItem icon={<User size={18} />} label="Informasi Toko" />
              <ProfileItem icon={<MapPin size={18} />} label="Alamat Pengiriman" />
              <ProfileItem icon={<Bell size={18} />} label="Notifikasi" />
              <ProfileItem icon={<ShoppingCart size={18} />} label="Metode Pembayaran" />
              <div className="h-px bg-gray-100 my-4"></div>
              <ProfileItem icon={<Info size={18} />} label="Pusat Bantuan" />
              <ProfileItem icon={<LogOut size={18} />} label="Keluar" danger />
            </div>
          </div>
        )}
      </div>

      {/* Bottom Nav */}
      <nav className="absolute bottom-0 w-full bg-white/80 backdrop-blur-md border-t border-gray-100 px-8 py-4 pb-8 flex items-center justify-between z-30">
        <NavIcon 
          active={activeTab === 'home'} 
          icon={<Home size={22} />} 
          onClick={() => setActiveTab('home')} 
        />
        <NavIcon 
          active={activeTab === 'catalog'} 
          icon={<Grid size={22} />} 
          onClick={() => setActiveTab('catalog')} 
        />
        <button 
          onClick={() => setActiveTab('cart')}
          className={`relative -mt-12 p-4 rounded-full shadow-xl border-4 border-white transform hover:scale-110 transition-all cursor-pointer ${
            activeTab === 'cart' ? 'bg-orange-500 shadow-orange-200' : 'bg-emerald-600 shadow-emerald-200'
          }`}
        >
          <ShoppingCart size={24} className="text-white" />
          <span className="absolute -top-1 -right-1 bg-red-500 text-white text-[8px] font-bold w-5 h-5 rounded-full flex items-center justify-center border-2 border-white">3</span>
        </button>
        <NavIcon 
          active={activeTab === 'orders'} 
          icon={<Clock size={22} />} 
          onClick={() => setActiveTab('orders')} 
        />
        <NavIcon 
          active={activeTab === 'profile'} 
          icon={<User size={22} />} 
          onClick={() => setActiveTab('profile')} 
        />
      </nav>
    </div>
  );
}

function ProfileItem({ icon, label, danger }: any) {
  return (
    <div className={`flex items-center justify-between p-4 bg-gray-50 rounded-2xl cursor-pointer hover:bg-gray-100 transition-all ${danger ? 'text-red-500' : 'text-gray-700'}`}>
      <div className="flex items-center gap-4 text-sm font-bold">
        {icon}
        <span>{label}</span>
      </div>
      <ChevronRight size={16} className={danger ? 'text-red-300' : 'text-gray-300'} />
    </div>
  );
}

function NavIcon({ icon, active, onClick }: any) {
  return (
    <button onClick={onClick} className={`transition-all ${active ? 'text-emerald-600' : 'text-gray-300'}`}>
      {icon}
      {active && <motion.div layoutId="mobile-indicator" className="w-1 h-1 bg-emerald-600 rounded-full mx-auto mt-1" />}
    </button>
  );
}
