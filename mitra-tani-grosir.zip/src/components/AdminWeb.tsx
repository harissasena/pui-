/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  LayoutDashboard, 
  Package, 
  ShoppingCart, 
  Users, 
  Settings, 
  LogOut, 
  Search,
  Bell,
  ChevronDown,
  TrendingUp,
  PackageCheck,
  Clock,
  ArrowUpRight,
  Plus
} from 'lucide-react';
import { motion } from 'motion/react';
import { PRODUCTS, ORDERS } from '../constants';

export default function AdminWeb() {
  const [activeTab, setActiveTab] = useState('dashboard');

  return (
    <div className="flex h-screen bg-[#F8F9FA] text-[#1A1A1A] font-sans overflow-hidden">
      {/* Sidebar */}
      <aside className="w-64 bg-white border-r border-[#E5E7EB] flex flex-col">
        <div className="p-6">
          <div className="flex items-center gap-2 text-emerald-600">
            <div className="bg-emerald-100 p-1.5 rounded-lg">
              <PackageCheck size={24} />
            </div>
            <span className="font-bold text-xl tracking-tight">Mitra Tani</span>
          </div>
        </div>

        <nav className="flex-1 px-4 py-4 space-y-1">
          <NavItem 
            icon={<LayoutDashboard size={20} />} 
            label="Dashboard" 
            active={activeTab === 'dashboard'} 
            onClick={() => setActiveTab('dashboard')} 
          />
          <NavItem 
            icon={<Package size={20} />} 
            label="Produk & Stok" 
            active={activeTab === 'inventory'} 
            onClick={() => setActiveTab('inventory')} 
          />
          <NavItem 
            icon={<ShoppingCart size={20} />} 
            label="Pesanan Grosir" 
            active={activeTab === 'orders'} 
            onClick={() => setActiveTab('orders')} 
          />
          <NavItem 
            icon={<Users size={20} />} 
            label="Manajemen Mitra" 
            active={activeTab === 'customers'} 
            onClick={() => setActiveTab('customers')} 
          />
          <NavItem 
            icon={<TrendingUp size={20} />} 
            label="Laporan Keuangan" 
            active={activeTab === 'reports'} 
            onClick={() => setActiveTab('reports')} 
          />
        </nav>

        <div className="p-4 mt-auto border-t border-[#E5E7EB]">
          <NavItem icon={<Settings size={20} />} label="Pengaturan" onClick={() => {}} />
          <NavItem icon={<LogOut size={20} />} label="Keluar" onClick={() => {}} className="text-red-500 hover:bg-red-50" />
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <header className="h-16 bg-white border-bottom border-[#E5E7EB] px-8 flex items-center justify-between">
          <div className="relative w-96">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
            <input 
              type="text" 
              placeholder="Cari pesanan, produk, atau mitra..." 
              className="w-full bg-[#F3F4F6] border-none rounded-full py-2 pl-10 pr-4 text-sm focus:ring-2 focus:ring-emerald-500 transition-all outline-none"
            />
          </div>
          
          <div className="flex items-center gap-4">
            <button className="p-2 text-gray-500 hover:bg-gray-100 rounded-full relative">
              <Bell size={20} />
              <span className="absolute top-2 right-2 w-2 h-2 bg-red-500 rounded-full border-2 border-white"></span>
            </button>
            <div className="h-8 w-px bg-gray-200 mx-2"></div>
            <div className="flex items-center gap-3 cursor-pointer">
              <div className="text-right">
                <p className="text-sm font-semibold">Admin Mitra Tani</p>
                <p className="text-[10px] text-gray-500 uppercase tracking-wider font-medium">Dwipa Karya, Sulawesi Tengah</p>
              </div>
              <img 
                src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=facearea&facepad=2&w=48&h=48&q=80" 
                alt="Profile" 
                className="w-10 h-10 rounded-full border-2 border-emerald-100"
              />
              <ChevronDown size={16} className="text-gray-400" />
            </div>
          </div>
        </header>

        {/* Content Area */}
        <div className="flex-1 overflow-y-auto p-8">
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3 }}
          >
            {activeTab === 'dashboard' && <DashboardContent />}
            {activeTab === 'inventory' && <InventoryContent />}
            {activeTab === 'orders' && <OrdersContent />}
            {activeTab === 'customers' && <CustomersContent />}
            {activeTab === 'reports' && <ReportsContent />}
          </motion.div>
        </div>
      </main>
    </div>
  );
}

function NavItem({ icon, label, active, onClick, className = '' }: any) {
  return (
    <button 
      onClick={onClick}
      className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all text-sm font-medium ${
        active 
          ? 'bg-emerald-600 text-white shadow-sm' 
          : 'text-gray-600 hover:bg-gray-100'
      } ${className}`}
    >
      {icon}
      <span>{label}</span>
      {active && <motion.div layoutId="active-indicator" className="ml-auto w-1.5 h-6 bg-white/20 rounded-full" />}
    </button>
  );
}

function DashboardContent() {
  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">Ringkasan Bisnis</h1>
        <div className="flex gap-2">
          <button className="flex items-center gap-2 px-4 py-2 bg-white border border-gray-200 rounded-lg text-sm font-medium hover:bg-gray-50">
            <Clock size={16} />
            7 Hari Terakhir
          </button>
          <button className="flex items-center gap-2 px-4 py-2 bg-emerald-600 text-white rounded-lg text-sm font-medium hover:bg-emerald-700 shadow-sm">
            <Plus size={16} />
            Unduh Laporan
          </button>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard title="Total Penjualan" value="Rp 124.5M" trend="+12.5%" icon={<TrendingUp className="text-emerald-500" />} color="emerald" />
        <StatCard title="Pesanan Baru" value="48" trend="+8" icon={<ShoppingCart className="text-blue-500" />} color="blue" />
        <StatCard title="Produk Aktif" value="156" trend="0" icon={<Package className="text-purple-500" />} color="purple" />
        <StatCard title="Mitra Terdaftar" value="1.2k" trend="+24" icon={<Users className="text-orange-500" />} color="orange" />
      </div>

      {/* Tables/Graphs Placeholder */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
          <div className="flex items-center justify-between mb-6">
            <h3 className="font-bold text-lg">Pesanan Terbaru</h3>
            <button className="text-emerald-600 text-sm font-semibold hover:underline">Lihat Semua</button>
          </div>
          <div className="space-y-4">
            {ORDERS.map(order => (
              <div key={order.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-xl">
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 bg-emerald-100 rounded-lg flex items-center justify-center text-emerald-700 font-bold text-xs">
                    {order.id.slice(-3)}
                  </div>
                  <div>
                    <p className="font-semibold text-sm">{order.customerName}</p>
                    <p className="text-xs text-gray-500">{order.date}</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="font-bold text-sm">Rp {order.total.toLocaleString('id-ID')}</p>
                  <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold uppercase ${
                    order.status === 'Shipped' ? 'bg-blue-100 text-blue-700' : 
                    order.status === 'Processed' ? 'bg-emerald-100 text-emerald-700' : 'bg-orange-100 text-orange-700'
                  }`}>
                    {order.status}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
          <h3 className="font-bold text-lg mb-6">Analitik Stok</h3>
          <div className="space-y-6">
            {PRODUCTS.slice(0, 4).map(product => (
              <div key={product.id}>
                <div className="flex justify-between items-end mb-2">
                  <p className="text-sm font-medium">{product.name}</p>
                  <p className="text-xs text-gray-500">{product.stock} {product.unit} tersisa</p>
                </div>
                <div className="w-full h-2 bg-gray-100 rounded-full overflow-hidden">
                  <motion.div 
                    initial={{ width: 0 }}
                    animate={{ width: `${(product.stock / 1000) * 100}%` }}
                    className={`h-full rounded-full ${product.stock < 200 ? 'bg-red-500' : 'bg-emerald-500'}`}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

function InventoryContent() {
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold">Produk & Stok Grosir</h1>
        <button className="px-4 py-2 bg-emerald-600 text-white rounded-lg text-sm font-semibold flex items-center gap-2 shadow-md shadow-emerald-100 transform active:scale-95 transition-all">
          <Plus size={18} /> Tambah Produk
        </button>
      </div>
      
      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
        <table className="w-full text-left">
          <thead>
            <tr className="bg-gray-50 text-gray-500 text-xs font-bold uppercase tracking-wider border-b border-gray-100">
              <th className="px-6 py-4">Produk</th>
              <th className="px-6 py-4">Kategori</th>
              <th className="px-6 py-4">Harga Grosir</th>
              <th className="px-6 py-4">Stok</th>
              <th className="px-6 py-4">Min. Order</th>
              <th className="px-6 py-4">Aksi</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-100">
            {PRODUCTS.map(product => (
              <tr key={product.id} className="hover:bg-gray-50/50 transition-colors">
                <td className="px-6 py-4">
                  <div className="flex items-center gap-3">
                    <img src={product.image} className="w-10 h-10 rounded-lg object-cover" alt="" />
                    <span className="font-semibold text-sm">{product.name}</span>
                  </div>
                </td>
                <td className="px-6 py-4 text-sm text-gray-600">{product.category}</td>
                <td className="px-6 py-4 font-bold text-sm">Rp {product.price.toLocaleString('id-ID')}/{product.unit}</td>
                <td className="px-6 py-4">
                  <span className={`px-2 py-1 rounded-md text-[10px] font-bold ${
                    product.stock > 100 ? 'bg-emerald-50 text-emerald-600' : 'bg-red-50 text-red-600'
                  }`}>
                    {product.stock} {product.unit}
                  </span>
                </td>
                <td className="px-6 py-4 text-sm font-medium">{product.minOrder} {product.unit}</td>
                <td className="px-6 py-4">
                  <div className="flex gap-2">
                    <button className="text-emerald-600 hover:bg-emerald-50 p-1.5 rounded-lg transition-all"><Settings size={16} /></button>
                    <button className="text-red-500 hover:bg-red-50 p-1.5 rounded-lg transition-all"><LogOut size={16} /></button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function OrdersContent() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">Semua Pesanan Grosir</h1>
        <div className="flex bg-white p-1 rounded-xl shadow-sm border border-gray-100">
          <button className="px-4 py-1.5 bg-emerald-600 text-white rounded-lg text-sm font-bold">Semua</button>
          <button className="px-4 py-1.5 text-gray-500 hover:bg-gray-50 rounded-lg text-sm font-bold">Aktif</button>
          <button className="px-4 py-1.5 text-gray-500 hover:bg-gray-50 rounded-lg text-sm font-bold">Selesai</button>
        </div>
      </div>
      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
        <table className="w-full text-left">
          <thead>
            <tr className="bg-gray-50 text-gray-500 text-xs font-bold uppercase tracking-wider border-b border-gray-100">
              <th className="px-6 py-4">ID Pesanan</th>
              <th className="px-6 py-4">Pelanggan</th>
              <th className="px-6 py-4">Tanggal</th>
              <th className="px-6 py-4">Total Bayar</th>
              <th className="px-6 py-4">Status</th>
              <th className="px-6 py-4">Aksi</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-100">
            {ORDERS.map(order => (
              <tr key={order.id} className="hover:bg-gray-50/50 transition-colors">
                <td className="px-6 py-4 text-sm font-bold text-emerald-600">{order.id}</td>
                <td className="px-6 py-4 text-sm font-medium">{order.customerName}</td>
                <td className="px-6 py-4 text-sm text-gray-500">{order.date}</td>
                <td className="px-6 py-4 text-sm font-bold text-gray-800 font-mono">Rp {order.total.toLocaleString('id-ID')}</td>
                <td className="px-6 py-4">
                  <span className={`px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wide ${
                    order.status === 'Shipped' ? 'bg-blue-100 text-blue-700' : 
                    order.status === 'Processed' ? 'bg-emerald-100 text-emerald-700' : 
                    'bg-orange-100 text-orange-700'
                  }`}>
                    {order.status}
                  </span>
                </td>
                <td className="px-6 py-4">
                  <button className="text-gray-400 hover:text-emerald-600 text-sm font-bold transition-all underline">Rincian</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function CustomersContent() {
  const customers = [
    { id: 1, name: 'Toko Kelontong Bu Siti', address: 'Bangga Jaya, Sulteng', orders: 12, spent: 45000000 },
    { id: 2, name: 'Warung Madura Berkah', address: 'Desa Dwipa Karya', orders: 8, spent: 22000000 },
    { id: 3, name: 'Minimarket Sejahtera', address: 'Bangga Pusat', orders: 5, spent: 15500000 },
  ];

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold">Manajemen Mitra (Toko)</h1>
        <button className="px-4 py-2 bg-emerald-600 text-white rounded-lg text-sm font-semibold flex items-center gap-2">
          <Plus size={18} /> Daftarkan Toko Baru
        </button>
      </div>
      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
        <table className="w-full text-left">
          <thead>
            <tr className="bg-gray-50 text-gray-500 text-xs font-bold uppercase tracking-wider border-b border-gray-100">
              <th className="px-6 py-4">Nama Toko</th>
              <th className="px-6 py-4">Alamat</th>
              <th className="px-6 py-4 text-center">Total Pesanan</th>
              <th className="px-6 py-4">Total Belanja</th>
              <th className="px-6 py-4">Aksi</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-100">
            {customers.map(c => (
              <tr key={c.id} className="hover:bg-gray-50/50 transition-colors">
                <td className="px-6 py-4">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full bg-emerald-100 flex items-center justify-center text-emerald-700 text-xs font-bold">
                      {c.name.charAt(0)}
                    </div>
                    <span className="font-semibold text-sm">{c.name}</span>
                  </div>
                </td>
                <td className="px-6 py-4 text-xs text-gray-500">{c.address}</td>
                <td className="px-6 py-4 text-center text-sm font-bold">{c.orders}</td>
                <td className="px-6 py-4 text-sm font-bold text-gray-700">Rp {c.spent.toLocaleString('id-ID')}</td>
                <td className="px-6 py-4">
                  <button className="text-emerald-600 font-bold text-sm">Lihat Profil</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function ReportsContent() {
  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">Laporan Keuangan</h1>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
          <p className="text-xs font-bold text-gray-400 uppercase tracking-widest mb-1">Pendapatan Bulan Ini</p>
          <h2 className="text-2xl font-bold text-emerald-600">Rp 45.300.000</h2>
          <p className="text-xs text-emerald-500 mt-2 font-bold">+8% vs bulan lalu</p>
        </div>
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
          <p className="text-xs font-bold text-gray-400 uppercase tracking-widest mb-1">Pengeluaran Stok</p>
          <h2 className="text-2xl font-bold text-orange-600">Rp 32.100.000</h2>
          <p className="text-xs text-orange-400 mt-2 font-bold">+2% vs bulan lalu</p>
        </div>
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
          <p className="text-xs font-bold text-gray-400 uppercase tracking-widest mb-1">Laba Bersih</p>
          <h2 className="text-2xl font-bold text-blue-600">Rp 13.200.000</h2>
          <p className="text-xs text-blue-400 mt-2 font-bold">+12% vs bulan lalu</p>
        </div>
      </div>

      <div className="bg-white p-8 rounded-2xl shadow-sm border border-gray-100 flex flex-col items-center justify-center py-20 text-center">
        <TrendingUp size={48} className="text-emerald-100 mb-4" />
        <h3 className="font-bold text-lg text-gray-800">Visualisasi Grafik Penjualan</h3>
        <p className="text-sm text-gray-400 max-w-sm mt-1">Gunakan Chart.js atau D3 untuk menampilkan performa penjualan grosir di sini.</p>
        <button className="mt-6 px-6 py-2 bg-emerald-600 text-white rounded-xl text-sm font-bold shadow-lg shadow-emerald-200">Buka Detail Analitik</button>
      </div>
    </div>
  );
}

function StatCard({ title, value, trend, icon, color }: any) {
  const colorClasses: Record<string, string> = {
    emerald: 'bg-emerald-50 text-emerald-600',
    blue: 'bg-blue-50 text-blue-600',
    purple: 'bg-purple-50 text-purple-600',
    orange: 'bg-orange-50 text-orange-600',
  };

  const bgClasses: Record<string, string> = {
    emerald: 'bg-emerald-500',
    blue: 'bg-blue-500',
    purple: 'bg-purple-500',
    orange: 'bg-orange-500',
  };

  return (
    <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 relative overflow-hidden">
      <div className={`absolute top-0 right-0 w-24 h-24 -mr-8 -mt-8 opacity-5 rounded-full ${bgClasses[color]}`}></div>
      <div className="flex justify-between items-start mb-4">
        <div className={`p-2 rounded-xl ${colorClasses[color].split(' ')[0]}`}>
          {icon}
        </div>
        <div className="flex items-center gap-1 text-[10px] font-bold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-full">
          <ArrowUpRight size={10} />
          {trend}
        </div>
      </div>
      <div>
        <p className="text-gray-500 text-xs font-bold uppercase tracking-wider mb-1">{title}</p>
        <p className="text-2xl font-bold">{value}</p>
      </div>
    </div>
  );
}
