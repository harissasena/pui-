/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Product, Order } from './types';

export const PRODUCTS: Product[] = [
  {
    id: 'p1',
    name: 'Beras Pandan Wangi 5kg',
    category: 'Sembako',
    price: 68000,
    unit: 'karung',
    stock: 200,
    minOrder: 10,
    image: 'https://images.unsplash.com/photo-1586201375761-83865001e31c?auto=format&fit=crop&q=80&w=400',
  },
  {
    id: 'p2',
    name: 'Minyak Goreng Bimoli 2L',
    category: 'Sembako',
    price: 34500,
    unit: 'pouch',
    stock: 500,
    minOrder: 12,
    image: 'https://images.unsplash.com/photo-1474979266404-7eaacbcd87c5?auto=format&fit=crop&q=80&w=400',
  },
  {
    id: 'p3',
    name: 'Gula Pasir Gulaku 1kg',
    category: 'Sembako',
    price: 16500,
    unit: 'pcs',
    stock: 1000,
    minOrder: 24,
    image: 'https://images.unsplash.com/photo-1622484211148-716598e04141?auto=format&fit=crop&q=80&w=400',
  },
  {
    id: 'p4',
    name: 'Indomie Goreng (Karton)',
    category: 'Jajanan',
    price: 115000,
    unit: 'dus',
    stock: 150,
    minOrder: 5,
    image: 'https://images.unsplash.com/photo-1569718212165-3a8278d5f624?auto=format&fit=crop&q=80&w=400',
  },
  {
    id: 'p5',
    name: 'Chiki Balls Keju 16g',
    category: 'Jajanan',
    price: 2000,
    unit: 'pcs',
    stock: 1200,
    minOrder: 40,
    image: 'https://images.unsplash.com/photo-1621447509374-f3a7638dcc94?auto=format&fit=crop&q=80&w=400',
  },
  {
    id: 'p6',
    name: 'Teh Pucuk Harum 350ml',
    category: 'Minuman',
    price: 3200,
    unit: 'botol',
    stock: 2400,
    minOrder: 24,
    image: 'https://images.unsplash.com/photo-1623067939982-d01073842c94?auto=format&fit=crop&q=80&w=400',
  }
];

export const ORDERS: Order[] = [
  {
    id: 'ORD-001',
    customerName: 'Toko Kelontong Bu Siti',
    date: '2024-03-15',
    total: 3400000,
    status: 'Shipped',
    items: [{ productId: 'p1', quantity: 50 }],
  },
  {
    id: 'ORD-002',
    customerName: 'Warung Madura Berkah',
    date: '2024-03-16',
    total: 1250000,
    status: 'Processed',
    items: [{ productId: 'p4', quantity: 10 }],
  },
  {
    id: 'ORD-003',
    customerName: 'Minimarket Sejahtera',
    date: '2024-03-16',
    total: 450000,
    status: 'Pending',
    items: [{ productId: 'p5', quantity: 200 }],
  },
];
