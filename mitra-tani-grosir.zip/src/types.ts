/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface Product {
  id: string;
  name: string;
  category: string;
  price: number;
  unit: string;
  stock: number;
  minOrder: number;
  image: string;
}

export interface Order {
  id: string;
  customerName: string;
  date: string;
  total: number;
  status: 'Pending' | 'Processed' | 'Shipped' | 'Delivered';
  items: { productId: string; quantity: number }[];
}

export type ViewMode = 'admin' | 'customer';
