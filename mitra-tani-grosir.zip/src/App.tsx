/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Monitor, Smartphone, ExternalLink, Github } from 'lucide-react';
import AdminWeb from './components/AdminWeb';
import MobileApp from './components/MobileApp';
import { ViewMode } from './types';
import { motion, AnimatePresence } from 'motion/react';

export default function App() {
  const [viewMode, setViewMode] = useState<ViewMode>('admin');

  return (
    <div className="min-h-screen bg-[#F0F2F5] relative overflow-hidden font-sans">
      {/* Background Decor */}
      <div className="absolute top-0 right-0 -translate-y-1/2 translate-x-1/2 w-[800px] h-[800px] bg-emerald-100/30 rounded-full blur-3xl pointer-events-none"></div>
      <div className="absolute bottom-0 left-0 translate-y-1/2 -translate-x-1/2 w-[600px] h-[600px] bg-emerald-50/50 rounded-full blur-3xl pointer-events-none"></div>

      {/* Floating Header UI Switcher */}
      <div className="fixed top-6 left-1/2 -translate-x-1/2 z-[100] flex items-center gap-1 bg-white/80 backdrop-blur-md p-1.5 rounded-full shadow-lg border border-white/50">
        <button
          onClick={() => setViewMode('admin')}
          className={`flex items-center gap-2 px-6 py-2.5 rounded-full text-sm font-bold transition-all ${
            viewMode === 'admin' 
            ? 'bg-emerald-600 text-white shadow-md shadow-emerald-100' 
            : 'text-gray-500 hover:bg-gray-100'
          }`}
        >
          <Monitor size={18} />
          Web Admin
        </button>
        <button
          onClick={() => setViewMode('customer')}
          className={`flex items-center gap-2 px-6 py-2.5 rounded-full text-sm font-bold transition-all ${
            viewMode === 'customer' 
            ? 'bg-emerald-600 text-white shadow-md shadow-emerald-100' 
            : 'text-gray-500 hover:bg-gray-100'
          }`}
        >
          <Smartphone size={18} />
          Mobile User
        </button>
      </div>

      {/* Viewport Rendering */}
      <main className="w-full h-screen">
        <AnimatePresence mode="wait">
          {viewMode === 'admin' ? (
            <motion.div
              key="admin"
              initial={{ opacity: 0, scale: 0.98 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 1.02 }}
              transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
              className="w-full h-full"
            >
              <AdminWeb />
            </motion.div>
          ) : (
            <motion.div
              key="mobile"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
              className="w-full h-full flex items-center justify-center p-12 bg-emerald-900/5 backdrop-blur-sm"
            >
              <div className="relative">
                {/* Visual context for mobile preview */}
                <div className="absolute -left-64 top-1/2 -translate-y-1/2 w-48 hidden lg:block space-y-4">
                  <div className="bg-white p-4 rounded-2xl shadow-sm border border-gray-100">
                    <p className="text-[10px] font-bold text-emerald-600 uppercase mb-1">User App</p>
                    <p className="text-sm font-medium text-gray-700">Aplikasi khusus mitra untuk belanja stok grosir langsung.</p>
                  </div>
                  <div className="flex items-center gap-2 text-emerald-700 text-xs font-bold">
                    <ExternalLink size={14} />
                    <span>Scan QR to Install</span>
                  </div>
                </div>

                <MobileApp />

                <div className="absolute -right-64 top-1/2 -translate-y-1/2 w-48 hidden lg:block space-y-4">
                  <div className="bg-white p-4 rounded-2xl shadow-sm border border-gray-100">
                    <p className="text-[10px] font-bold text-emerald-600 uppercase mb-1">Fitur Utama</p>
                    <ul className="text-xs text-gray-600 space-y-2">
                      <li>• Katalog Harga Grosir</li>
                      <li>• Pelacakan Pengiriman</li>
                      <li>• Update Stok Real-time</li>
                      <li>• Pembayaran Mudah</li>
                    </ul>
                  </div>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* Info Badge */}
      <div className="fixed bottom-6 right-6 z-[100]">
        <div className="bg-white/90 backdrop-blur-sm border border-gray-100 px-4 py-2 rounded-2xl shadow-lg flex items-center gap-3">
          <div className="flex flex-col">
            <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Skripsi Project</p>
            <p className="text-sm font-bold text-gray-800">Sistem Grosir Mitra Tani</p>
          </div>
          <div className="w-8 h-8 bg-emerald-600 flex items-center justify-center rounded-xl text-white">
            <Github size={18} />
          </div>
        </div>
      </div>
    </div>
  );
}
